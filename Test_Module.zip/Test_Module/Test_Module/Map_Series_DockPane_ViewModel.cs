﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Editing.Attributes;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Controls;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Internal.KnowledgeGraph.FFP;
using ArcGIS.Desktop.Internal.Mapping;
using ArcGIS.Desktop.KnowledgeGraph;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Documents;
using System.Windows.Input;
using static ArcGIS.Desktop.Internal.Mapping.PropertyPages.LocatorField;

namespace Test_Module
{
    internal class Map_Series_DockPane_ViewModel : DockPane
    {
        private const string _dockPaneID = "Test_Module_Dockpane1";

        private ObservableCollection<MapSeries> _map_series_list = new ObservableCollection<MapSeries>();

        // Declare Veiw Model
        protected Map_Series_DockPane_ViewModel() { }

        public ObservableCollection<MapSeries> MapSeriesList
        {
            get { return _map_series_list; }
        }

        public ObservableCollection<CIMMapSeries> MapSeriesDropDown
        {
            get
            {
                var map_frame_name_list = _map_series_list.Select(item => item.GetDefinition()).ToList();
                ObservableCollection<CIMMapSeries> observable_list = new ObservableCollection<CIMMapSeries>();
                observable_list.Union(map_frame_name_list);
                //observable_list.Union((List<ComboBox>) map_frame_name_list);
                return observable_list;
            }
        }

        private string _selected_map_series;
        public string SelectedMapSeries
        {
            get { return _selected_map_series; }
            set { SetProperty(ref _selected_map_series, value, () => SelectedMapSeries); }
        }

        /// <summary>
        /// Show the DockPane.
        /// </summary>
        protected override async Task InitializeAsync()
        {
            await QueuedTask.Run(() =>
            {
                var layouts = Project.Current.GetItems<LayoutProjectItem>();
                var map_series_list = layouts.Select(item => item.GetLayout().MapSeries).ToList();
                _map_series_list.Union(map_series_list);
            });
        }

        //public async Task GetMSInfo()
        //{
        //    LayoutProjectItem lytItem = Project.Current.GetItems<LayoutProjectItem>()
        //                .FirstOrDefault(item => item.Name.Contains("Profile"));
        //    MessageBox.Show($"lytItem: {lytItem}", "Map Series Info");
        //    Layout map_series_layout = lytItem.GetLayout();
        //    MessageBox.Show($"map_series_layout: {map_series_layout}", "Map Series Info");
        //    MapSeries MS = map_series_layout.MapSeries;
        //    MessageBox.Show($"MS: {MS}", "Map Series Info");
        //    MessageBox.Show($"Current Page: {MS.CurrentPageNumber}\nNext Page: {MS.NextPageNumber}", "Map Series Info");
        //}

        public ICommand CmdEsriStyleButton
        {
            get
            {
                return new RelayCommand((cmdParams) =>
                {
                    var layouts = Project.Current.GetItems<LayoutProjectItem>();
                    var layout_names = layouts.Select(item => item.Name).ToList();
                    var map_series_list = layout_names;

                    MessageBox.Show($@"Esri styled button was clicked with this parameter {Environment.NewLine}{cmdParams}\n{layout_names}");
                }, () => true);
            }
        }

        public ICommand ShowMSInfo
        {
            get
            {
                return new RelayCommand(async () =>
                {
                    MessageBox.Show($@"Map Series {Environment.NewLine}{MapSeriesList[0].CurrentPageName}");
                }, () => true);
            }
        }


        /// <summary>
        /// Show the DockPane.
        /// </summary>
        internal static void Show()
        {
            DockPane pane = FrameworkApplication.DockPaneManager.Find(_dockPaneID);
            if (pane == null)
                return;

            pane.Activate(); 
        }

        /// <summary>
        /// Text shown near the top of the DockPane.
        /// </summary>
        private string _heading = "Map Series Options";

        public string Heading
        {
            get => _heading;
            set => SetProperty(ref _heading, value);
        }
    }

    /// <summary>
    /// Button implementation to show the DockPane.
    /// </summary>
    internal class Map_Series_DockPane_ShowButton : Button
    {
        protected override void OnClick()
        {
            Map_Series_DockPane_ViewModel.Show();
        }
    }
}
