﻿using ArcGIS.Core.CIM;
using ArcGIS.Core.Data;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Catalog;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Editing;
using ArcGIS.Desktop.Extensions;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;
using ArcGIS.Desktop.Framework.Dialogs;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.KnowledgeGraph;
using ArcGIS.Desktop.Layouts;
using ArcGIS.Desktop.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test_Module
{
    internal class Button1 : Button
    {
        protected override async void OnClick()
        {
            LayoutProjectItem lytItem = Project.Current.GetItems<LayoutProjectItem>()
                         .FirstOrDefault(item => item.Name.Contains("Profile"));
            
            await QueuedTask.Run(() =>
            {
                // Get map series page and display as json
                Layout map_series_layout = lytItem.GetLayout();
                MapSeries MS = map_series_layout.MapSeries as MapSeries;
                // ArcGIS.Desktop.Framework.Dialogs.MessageBox.Show($"Current Page: {MS.CurrentPageNumber}\nNext Page: {MS.NextPageNumber}", "CIM Info");

                MS.SetCurrentPageNumber(MS.NextPageNumber);

                CIMMapSeries CIM_MS = MS.GetDefinition();
                // ArcGIS.Desktop.Framework.Dialogs.MessageBox.Show($"Layout: {map_series_layout}\n" + $"CIM Map Series: {CIM_MS.ToJson()}", "CIM Info");

                // JSON attributes of note (CIMMapSeries):
                // indexLayerURI : "CIMPATH=txdot_plan_view/frames_planview.json"
                // nameField: "Page_Number"
                // sortField: "Page_Number"
                // currentPageID

                var current_page_oid = CIM_MS.CurrentPageID;

                // Update this to get path from map series CIM rather than looking for "frames"
                // var frames_features = MapView.Active.Map.GetLayersAsFlattenedList().OfType<ArcGIS.Desktop.Mapping.FeatureLayer>().FirstOrDefault(item => item.Name.Contains("Frames"));

                //    // create an instance of the inspector class
                //    var insp = new ArcGIS.Desktop.Editing.Attributes.Inspector();
                //    // load the layer
                //    insp.Load(CIM_MS.ToJson()['IndexLayer']);

                //    ArcGIS.Desktop.Editing.Attributes.Attribute att = insp.FirstOrDefault(a => a.FieldName == "TEXTSTRING");

                //    // iterate through the attributes, looking at properties
                //    foreach (var attribute in insp)
                //    {
                //        if attribute.FieldName.Contains("Page") {
                //            ArcGIS.Desktop.Framework.Dialogs.MessageBox.Show($"Layout:  {map_series_layout}\n" + $"Page: {map_series_page}", "Layout Info");
                //        }
                //        var fldName = attribute.FieldName;
                //        var fldAlias = attribute.FieldAlias;
                //        var fldType = attribute.FieldType;
                //        int idxFld = attribute.FieldIndex;
                //        var fld = attribute.GetField();
                //        var isNullable = attribute.IsNullable;
                //        var isEditable = attribute.IsEditable;
                //        var isVisible = attribute.IsVisible;
                //        var isSystemField = attribute.IsSystemField;
                //        var isGeometryField = attribute.IsGeometryField;
                //    }


            });  // Perform on the worker thread

            // ArcGIS.Desktop.Framework.Dialogs.MessageBox.Show($"Layout:  {map_series_layout}\n" + $"Page: {map_series_page}", "Layout Info");



            // string stringURI = ArcGIS.Desktop.Core.Project.Current.URI;
            // ArcGIS.Desktop.Framework.Dialogs.MessageBox.Show($"Project path:  {stringURI}", "Project Info");
        }
    }
}
